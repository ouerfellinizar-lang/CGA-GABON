# CGA Gabon — Gestion Commerciale

Application web de gestion commerciale pour le Comptoir Général d'Aluminium (Gabon).

## Fonctionnalités

- 🔐 Connexion avec niveaux d'accès (Admin, Commercial, Chef d'atelier, Metteur)
- 📊 Tableau de bord avec statistiques dossiers
- 📋 Création et gestion de devis complets
- 🪟 Catalogue EXLABESA (NOVA, EX-55 à EX-90, Baies, Portes, Portails…)
- 🤝 8 partenaires : EXLABESA, Larson, Saint-Gobain, Master Bond, ACM, ASA, Somfy, Luxe Perfil
- 💰 Prix en FCFA avec TVA et remises
- 💾 Sauvegarde dans Supabase (base de données cloud)
- 🖨️ Impression : Devis + Contrat, Facture, Bon de commande, BL, OF, Fiche réception

## Déploiement sur Vercel

### Méthode 1 — GitHub + Vercel (recommandé)

1. Créer un compte sur [github.com](https://github.com)
2. Créer un nouveau repository `cga-gabon`
3. Uploader tous les fichiers de ce dossier
4. Aller sur [vercel.com](https://vercel.com) → "Add New Project"
5. Connecter votre repository GitHub
6. Vercel détecte Vite automatiquement → cliquer "Deploy"
7. Votre app sera disponible sur `https://cga-gabon.vercel.app`

### Méthode 2 — Vercel CLI (direct)

```bash
npm install -g vercel
npm install
vercel --prod
```

## Développement local

```bash
npm install
npm run dev
# Ouvrir http://localhost:3000
```

## Configuration Supabase

La connexion Supabase est déjà configurée dans `src/App.jsx`.

Tables requises dans Supabase (SQL Editor) :
```sql
CREATE TABLE IF NOT EXISTS dossiers (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  devis_num text UNIQUE NOT NULL,
  statut text DEFAULT 'prospect',
  client_nom text, client_tel text, client_email text,
  chantier_adresse text, chantier_ville text,
  technicien text, commercial text,
  lignes jsonb DEFAULT '[]',
  avances jsonb DEFAULT '[]',
  remise numeric DEFAULT 0, tva numeric DEFAULT 18,
  remarque text, conditions text, delai text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE dossiers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "acces" ON dossiers FOR ALL TO anon USING (true) WITH CHECK (true);
```

## Contact

Comptoir Général d'Aluminium — GABON
2 Rue Paul Manon, Libreville
Tél : +241 77 90 72 04
Email : contact@cga-gabon.com
Immat. : 48161W
